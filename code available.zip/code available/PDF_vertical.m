clear;clc;
ll=48;
st=datenum(2021,1,1)-datenum(2020,12,31);
ed=datenum(2021,12,31)-datenum(2020,12,31);

load('E:\LH\mat\data57516.mat'); %StationNum,ObservTime,Latitude,Longitude,SampHeight,HorizWindD,HorizWindV,VertiWindV,HorizCredib,VertiCredib,Cn2Value
load('E:\LH\mat\uusd57516.mat');
load('E:\LH\cn2\htera.mat');
load('E:\LH\mat\ueof57516.mat');
load('E:\LH\mat\ugau57516.mat');

wd57516=reshape(squeeze(data57516(st:ed,1:12:end,6,1:ll)),[(ed-st+1)*24 ll]); wd57516(wd57516==99999)=nan;
ws57516=reshape(squeeze(data57516(st:ed,1:12:end,7,1:ll)),[(ed-st+1)*24 ll]); ws57516(ws57516==99999)=nan; 
uucn57516=-ws57516.*sin(wd57516./180*pi);

uusd16=reshape(uusd57516,[(ed-st+1)*2 ll]); 
data57516(data57516==99999)=nan;
uucn16=squeeze(-data57516(st:ed,1,7,1:ll).*sin(data57516(st:ed,1,6,1:ll)./180*pi));


load('E:\LH\mat\ht.mat');
load('E:\LH\mat\htsd.mat'); %day, line number, var(),layer

for j=1:length(usd16)
    usd16(j,1:length(htsd))=interp1(htsd,uusd16(j,:),ht);
end



l=30;l1=-30;
    h=figure;
    set(h,'position',[50 50 1400 700]);

        devidata=usd16-uucn16;
        devidata1=usd16-ugau57516;



        for i=1:7
            

            ndata=reshape(devidata(:,httmp(i):httmp(i+1)-1),[length(devidata)*(httmp(i+1)-httmp(i)) 1]);
            ndata(isnan(ndata))=[];
            mdata=reshape(devidata1(:,httmp(i):httmp(i+1)-1),[length(devidata1)*(httmp(i+1)-httmp(i)) 1]);
            mdata(isnan(mdata))=[];       
      
            if length(ndata)*length(mdata)~=0
            handaxe=axes('position',[0.08 hh 0.39 ll1]);
            createFit(ndata,mdata,i);    
            xlim([l1 l]);
            ylim([0 .15]);
            set(handaxe,'Box','off')
            if hh==0.12
            set(handaxe,'xtick',l1:10:l,'xticklabel',l1:10:l,'fontsize',15,'fontweight','bold');
            xlabel('RS-WPR zonal wind(m/s)','fontsize',15,'fontweight','bold');  
                       set(handaxe,'xminortick','on');
            else
            set(handaxe,'xtick',[],'xcolor','w');
             
            end
            set(handaxe,'yticklabel',[]);
            set(handaxe,'yminortick','on');
            text(-32,0,num2str(i-1),'fontsize',15,'fontweight','bold');

            hh=hh+ll1;
            end              
            if i==7
            text(-32,0.15,num2str(i),'fontsize',15,'fontweight','bold');
           end
            if i==4
                text(-34,0,'Height(m)','fontsize',15,'fontweight','bold','Rotation',90);
            end

        end


        lgd=legend('RS-Gauss filter WPR','RS-original WPR','location','north','Orientation','horizontal','Box','off');    



        devidata2=usd16-uucn16;
        devidata3=usd16-ueof57516;

hh=0.12;
        for i=1:7
            

            ndata=reshape(devidata3(:,httmp(i):httmp(i+1)-1),[length(devidata3)*(httmp(i+1)-httmp(i)) 1]);
            ndata(isnan(ndata))=[];
            mdata=reshape(devidata2(:,httmp(i):httmp(i+1)-1),[length(devidata2)*(httmp(i+1)-httmp(i)) 1]);
            mdata(isnan(mdata))=[];       
      
            if length(ndata)*length(mdata)~=0
            handaxe=axes('position',[0.55 hh 0.39 ll1]);
            createFit(ndata,mdata,i);    
            xlim([l1 l]);
            ylim([0 .15]);
            set(handaxe,'Box','off')
            if hh==0.12
            set(handaxe,'xtick',l1:10:l,'xticklabel',l1:10:l,'fontsize',15,'fontweight','bold');
            xlabel('RS-WPR zonal wind(m/s)','fontsize',17,'fontweight','bold');  
            set(handaxe,'xminortick','on');
             set(handaxe,'yminortick','on');
            else
            set(handaxe,'xtick',[],'xcolor','w');
             
            end
            set(handaxe,'yticklabel',[]);
            set(handaxe,'yminortick','on');
            text(-32,0,num2str(i-1),'fontsize',17,'fontweight','bold');

            hh=hh+ll1;
            end              
            if i==7
            text(-32,0.15,num2str(i),'fontsize',17,'fontweight','bold');

            end
            if i==4
                text(-34,0,'Height(km)','fontsize',17,'fontweight','bold','Rotation',90);
            end


        end
        lgd=legend('RS-EOF construction WPR','RS-original WPR','location','north','Orientation','horizontal','Box','off');  

function pd1 = createFit(ndata,mdata,i) 
pori={'75.6%','79.4%','87.4%','86.5%','86.9%','96.4%','98.2%'};

LegHandles = []; LegText = {};

[CdfF,CdfX] = ecdf(ndata,'Function','cdf'); 
BinInfo.rule = 5;
BinInfo.width = 0.5;
BinInfo.placementRule = 1;
[~,BinEdge] = internal.stats.histbins(ndata,[],[],BinInfo,CdfF,CdfX);
[BinHeight,BinCenter] = ecdfhist(CdfF,CdfX,'edges',BinEdge);
hLine = bar(BinCenter,BinHeight*BinInfo.width,'hist');hold on;
set(hLine,'FaceColor',[204 0  0]/255,'EdgeColor',[204 0  0]/255,...
    'LineStyle','-', 'LineWidth',0.5, 'facealpha', '.3');%%bp
[~,a]=find(abs(BinCenter+10)==min(abs(BinCenter+10)));
[~,b]=find(abs(BinCenter-10)==min(abs(BinCenter-10)));
text(23,0.07,[sprintf('%4.1f',sum(BinHeight(1,a:b))/sum(BinHeight)*100),'%'],'Color',[204 0  0]/255,'fontsize',15,'fontweight','bold');%max(BinHeight)*0.9
LegHandles(end+1) = hLine;
LegText{end+1} = 'ydata data';
XLim = get(gca,'XLim');
XLim = XLim + [-1 1] * 0.01 * diff(XLim);
XGrid = linspace(XLim(1),XLim(2),100);

pd1 = fitdist(ndata, 'normal');
YPlot = pdf(pd1,XGrid)*BinInfo.width;

LegHandles(end+1) = hLine;
LegText{end+1} = 'fit 1 copy 1';

hold on;

[CdfF,CdfX] = ecdf(mdata,'Function','cdf');  % compute empirical cdf

[~,BinEdge] = internal.stats.histbins(mdata,[],[],BinInfo,CdfF,CdfX);
[BinHeight,BinCenter] = ecdfhist(CdfF,CdfX,'edges',BinEdge);
hLine = bar(BinCenter,BinHeight*BinInfo.width,'hist');hold on;
set(hLine,'FaceColor',[51 204  255]/255,'EdgeColor',[51 204  255]/255,...
    'LineStyle','-', 'LineWidth',0.5, 'facealpha', '.3');
[~,a]=find(abs(BinCenter+10)==min(abs(BinCenter+10)));
[~,b]=find(abs(BinCenter-10)==min(abs(BinCenter-10)));
text(16,0.07,[cell2mat(pori(8-i)),'\'],'Color',[51 204  255]/255,'fontsize',15,'fontweight','bold');%max(BinHeight)*0.9
LegHandles(end+1) = hLine;
LegText{end+1} = 'mdata data';

% Create grid where function will be computed
XLim = get(gca,'XLim');
XLim = XLim + [-1 1] * 0.01 * diff(XLim);
XGrid = linspace(XLim(1),XLim(2),100);

pd1 = fitdist(mdata, 'normal');
YPlot = pdf(pd1,XGrid)*BinInfo.width;


LegHandles(end+1) = hLine;
LegText{end+1} = 'fit 1 copy 1';


hold on;
set(gca,'fontsize',15,'fontweight','bold');

box on;
hold on;
end