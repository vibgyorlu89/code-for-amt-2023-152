clear;clc;
ll=45;
load('E:\LH\mat\miecn.mat');
load('E:\LH\mat\rayleighcn.mat');
load('E:\LH\mat\mie.mat');
load('E:\LH\mat\rayleigh.mat');
load('E:\LH\mat\ht.mat');
load('E:\LH\mat\ht1.mat'); 
lonlat=[108.76,28.84];




l1=-60;l=60;

raydata=rayleigh-rayleighcn(:,1);
raydata_gau=rayleigh-rayleighcn(:,2);
raydata_eof=rayleigh-rayleighcn(:,3);

h=figure;
set(h,'position',[50 50 1000 1200]);
handaxe=axes('position',[0.08 0.85 0.39 0.12]);
pd1=createFit(raydata,raydata_gau,[255 153 153]/255);
hold on; 
box on;

xlim([-60 60]);
ylim([0 0.25]);
set(gca,'ytick',0:0.1:0.25,'yticklabel',0:0.1:0.25,'fontsize',15,'fontweight','bold');
ylabel('Frequency','fontsize',15,'fontweight','bold');
set(handaxe,'xtick',[],'xcolor','w');
text(-55,0.2,'(a)','fontsize',16,'fontweight','bold');
lgd=legend('Rayleigh-Gauss filter WPR','Rayleigh-original WPR', ...
    'location','south','Orientation','horizontal','Box','off');  
        set(handaxe,'xminortick','on');
        set(handaxe,'yminortick','on');

handaxe=axes('position',[0.55 0.85 0.39 0.12]);
createFit(raydata,raydata_eof,[153 204 255]/255);
xlim([-60 60]);
ylim([0 0.25]);
set(gca,'ytick',0:0.1:0.25,'yticklabel',0:0.1:0.25,'fontsize',15,'fontweight','bold');
ylabel('Frequency','fontsize',15,'fontweight','bold');
set(handaxe,'xtick',[],'xcolor','w');
box on;
text(-55,0.2,'(b)','fontsize',16,'fontweight','bold');
lgd=legend('Rayleigh-EOF WPR', ...
    'location','south','Orientation','horizontal','Box','off');   
        set(handaxe,'xminortick','on');
        set(handaxe,'yminortick','on');

ax2=axes;
ax2.Position=[0.08 0.57 0.39 0.14];
createFit2(rayleigh,rayleighcn(:,1),'WPR',[255 153 153]/255,2);
ax3=axes('Parent',gcf);hold(ax3,'on')
ax3.Position=[0.08 0.71 0.39 0.14];
createFit2(rayleigh,rayleighcn(:,2),'WPR Gauss filter',[255 153 153]/255,3);
ax3.XTickLabel='';
set(ax2,'xminortick','on');
set(ax2,'yminortick','on');

% (b)
ax2=axes;%('Parent',gcf);%hold(ax2,'on')
ax2.Position=[0.55 0.57 0.39 0.14];
createFit2(rayleigh,rayleighcn(:,1),'WPR',[153 204 255]/255,2);
ax3=axes('Parent',gcf);hold(ax3,'on')
ax3.Position=[0.55 0.71 0.39 0.14];
createFit2(rayleigh,rayleighcn(:,3),'WPR EOF',[153 204 255]/255,3);
ax3.XTickLabel='';
set(ax2,'xminortick','on');
set(ax2,'yminortick','on');

miedata=mie-miecn(:,1);
miedata_gau=mie-miecn(:,2);
miedata_eof=mie-miecn(:,3);

 %(c)                                 
ax2=axes;%('Parent',gcf);%hold(ax2,'on')
ax2.Position=[0.08 0.08 0.39 0.14];
createFit1(mie,mie(:,1),'WPR',[255 153 153]/255,2);
ax3=axes('Parent',gcf);hold(ax3,'on')
ax3.Position=[0.08 0.22 0.39 0.14];
createFit1(mie,mie(:,2),'WPR Gauss filter',[255 153 153]/255,3);
ax3.XTickLabel='';
set(ax2,'xminortick','on');
set(ax2,'yminortick','on');
%(d)

% handaxe=axes('position',[0.55 0.08 0.39 0.28]);
ax2=axes;%('Parent',gcf);%hold(ax2,'on')
ax2.Position=[0.55 0.08 0.39 0.14];
createFit1(mie,mie(:,1),'WPR',[153 204 255]/255,2);
ax3=axes('Parent',gcf);hold(ax3,'on')
ax3.Position=[0.55 0.22 0.39 0.14];
createFit1(mie,mie(:,3),'WPR EOF',[153 204 255]/255,3);
ax3.XTickLabel='';
set(ax2,'xminortick','on');
set(ax2,'yminortick','on');


handaxe=axes('position',[0.55 0.36 0.39 0.12]);
createFit(miedata,miedata(:,3),[153 204 255]/255);
xlim([-60 60]);
ylim([0 0.25]);
set(gca,'ytick',0:0.1:0.25,'yticklabel',0:0.1:0.25,'fontsize',15,'fontweight','bold');
ylabel('Frequency','fontsize',15,'fontweight','bold');
set(handaxe,'xtick',[],'xcolor','w');
box on;
text(-55,0.2,'(d)','fontsize',16,'fontweight','bold');
lgd=legend('Mie-EOF WPR',...
    'location','south','Orientation','horizontal','Box','off');    
        set(handaxe,'xminortick','on');
        set(handaxe,'yminortick','on');

handaxe=axes('position',[0.08 0.36 0.39 0.12]);
createFit(miedata,miedata(:,2),[255 153 153]/255);
xlim([-60 60]);
ylim([0 0.25]);
set(gca,'ytick',0:0.1:0.25,'yticklabel',0:0.1:0.25,'fontsize',15,'fontweight','bold');
ylabel('Frequency','fontsize',15,'fontweight','bold');
text(-55,0.2,'(c)','fontsize',16,'fontweight','bold');
set(handaxe,'xtick',[],'xcolor','w');
box on;
lgd=legend('EOF-Gauss filter WPR','Mie-original WPR', ...
    'location','south','Orientation','horizontal','Box','off');    %'

        set(handaxe,'xminortick','on');
        set(handaxe,'yminortick','on');

function pd2=createFit1(mdata,ndata,str,clr,nm)

l1=-60;l=60;
[CdfF,CdfX] = ecdf(mdata,'Function','cdf'); 
BinInfo.rule = 5;
BinInfo.width = 5;
BinInfo.placementRule = 1;
[~,BinEdge] = internal.stats.histbins(mdata,[],[],BinInfo,CdfF,CdfX);
[BinHeight,BinCenter] = ecdfhist(CdfF,CdfX,'edges',BinEdge);
hLine = bar(BinCenter,BinHeight*BinInfo.width,'hist');hold on;
set(hLine,'FaceColor',[0.78 0.88 0.82],'EdgeColor','none', 'facealpha', '.7');% 
hold on;

[CdfF,CdfX] = ecdf(ndata,'Function','cdf');  % compute empirical cdf
[~,BinEdge] = internal.stats.histbins(ndata,[],[],BinInfo,CdfF,CdfX);
[BinHeight,BinCenter] = ecdfhist(CdfF,CdfX,'edges',BinEdge);
hLine = bar(BinCenter,BinHeight*BinInfo.width,'hist');hold on;
set(hLine,'FaceColor','white','EdgeColor',clr,...
    'LineStyle','-', 'LineWidth',2);


xlim([l1 l]);
ylim([0 0.37]);
set(gca,'fontsize',15,'fontweight','bold');box on;
ylabel('Frequency','fontsize',15,'fontweight','bold');
if nm==2
xlabel('Mie wind(m/s)','fontsize',15,'fontweight','bold');   
end
lgd=legend('Mie',str, ...
    'location','south','Box','off');
        set(gca,'xminortick','on');
        set(gca,'yminortick','on');
    




end


function pd2=createFit2(mdata,ndata,str,clr,nm)

l1=-60;l=60;
[CdfF,CdfX] = ecdf(mdata,'Function','cdf'); 
BinInfo.rule = 5;
BinInfo.width = 5;
BinInfo.placementRule = 1;
[~,BinEdge] = internal.stats.histbins(mdata,[],[],BinInfo,CdfF,CdfX);
[BinHeight,BinCenter] = ecdfhist(CdfF,CdfX,'edges',BinEdge);
hLine = bar(BinCenter,BinHeight*BinInfo.width,'hist');hold on;
set(hLine,'FaceColor',[0.78 0.88 0.82],'EdgeColor','none', 'facealpha', '.7');%%bp
hold on;

[CdfF,CdfX] = ecdf(ndata,'Function','cdf');  % compute empirical cdf
[~,BinEdge] = internal.stats.histbins(ndata,[],[],BinInfo,CdfF,CdfX);
[BinHeight,BinCenter] = ecdfhist(CdfF,CdfX,'edges',BinEdge);
hLine = bar(BinCenter,BinHeight*BinInfo.width,'hist');hold on;
set(hLine,'FaceColor','white','EdgeColor',clr,...
    'LineStyle','-', 'LineWidth',2, 'facealpha', '.99');


xlim([l1 l]);
ylim([0 0.37]);
set(gca,'fontsize',15,'fontweight','bold');box on;
ylabel('Frequency','fontsize',15,'fontweight','bold');
if nm==2
xlabel('Rayleigh wind(m/s)','fontsize',15,'fontweight','bold');   
end
lgd=legend('Rayleigh',str, ...
    'location','south','Box','off');
        set(gca,'xminortick','on');
        set(gca,'yminortick','on');
    




end

function pd1 = createFit(mdata,ndata,clr) %%dfittool

LegHandles = []; LegText = {};

[CdfF,CdfX] = ecdf(ndata,'Function','cdf');  % compute empirical cdf
BinInfo.rule = 5;
BinInfo.width = 4;
BinInfo.placementRule = 1;
[~,BinEdge] = internal.stats.histbins(ndata,[],[],BinInfo,CdfF,CdfX);
[BinHeight,BinCenter] = ecdfhist(CdfF,CdfX,'edges',BinEdge);

XGrid = linspace(-60,60,100);


hold on;
% --- Plot data originally in dataset "ydata data"
[CdfF,CdfX] = ecdf(mdata,'Function','cdf');  % compute empirical cdf
BinInfo.rule = 5;
BinInfo.width = 4;
BinInfo.placementRule = 1;
[~,BinEdge] = internal.stats.histbins(mdata,[],[],BinInfo,CdfF,CdfX);
[BinHeight,BinCenter] = ecdfhist(CdfF,CdfX,'edges',BinEdge);

pd1 = fitdist(ndata, 'normal');
YPlot = pdf(pd1,XGrid)*BinInfo.width;
hLine = plot(XGrid,YPlot,'Color',clr,...
    'LineStyle','-', 'LineWidth',2,...
    'Marker','*','MarkerIndices',1:5:length(YPlot), 'MarkerSize',6);%
% Fit this distribution to get parameter values
pd1 = fitdist(mdata, 'normal');
YPlot = pdf(pd1,XGrid)*BinInfo.width;
hLine = plot(XGrid,YPlot,'Color',[0 153 0]/255,...
    'LineStyle','-', 'LineWidth',2,...
    'Marker','none', 'MarkerSize',6);%%bp
% LegHandles(end+1) = hLine;
% LegText{end+1} = 'fit 1 copy 1';
% lgd=legend(str, ...
%     'location','south','Box','off');
hold on;


box on;
hold on;
end