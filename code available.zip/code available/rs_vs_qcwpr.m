clear;clc;
ll=48;
st=datenum(2021,1,1)-datenum(2020,12,31);
ed=datenum(2021,12,31)-datenum(2020,12,31);

load('E:\LH\mat\data57516.mat'); %StationNum,ObservTime,Latitude,Longitude,SampHeight,HorizWindD,HorizWindV,VertiWindV,HorizCredib,VertiCredib,Cn2Value
load('E:\LH\mat\uusd57516.mat');
load('E:\LH\cn2\htera.mat');
load('E:\LH\mat\ueof57516.mat');
load('E:\LH\mat\ugau57516.mat');

wd57516=reshape(squeeze(data57516(st:ed,1:12:end,6,1:ll)),[(ed-st+1)*24 ll]); wd57516(wd57516==99999)=nan;
ws57516=reshape(squeeze(data57516(st:ed,1:12:end,7,1:ll)),[(ed-st+1)*24 ll]); ws57516(ws57516==99999)=nan; 
uucn57516=-ws57516.*sin(wd57516./180*pi);

uusd16=reshape(uusd57516,[(ed-st+1)*2 ll]); 
data57516(data57516==99999)=nan;
uucn16=squeeze(-data57516(st:ed,1,7,1:ll).*sin(data57516(st:ed,1,6,1:ll)./180*pi));


load('E:\LH\mat\ht.mat');
load('E:\LH\mat\htsd.mat'); %day, line number, var(),layer

for j=1:length(usd16)
    usd16(j,1:length(htsd))=interp1(htsd,uusd16(j,:),ht);
end

%% qc

% ws16=fillmissing(uucn57516,'linear')-1;
% ws33=fillmissing(uucn57633,'linear')-1;
% 
% data=ws16';
% % data(:,289:576)=vv;
% [r1,c1]=size(data);
% x=data(2:end,2:end);
% [m,n]=size(x);
% for i=1:m
%     meanx(i,1)=mean(x(i,:));
% %     x(i,:)=x(i,:);
%    
% end
% c=x*x'/n;
% [EOF,E]=eig(c);
% PC=EOF'*x;
% E=fliplr(flipud(E));
% lambda=diag(E); %����ֵ
% EOF=fliplr(EOF);%ÿ�д�������������ģ̬��
% PC=flipud(PC);%ÿ��ʱ��ϵ��
% r=lambda/sum(lambda);%�������
% e0=lambda*sqrt(2/m);
% e(:,1)=lambda-e0;%�������������
% e(:,2)=lambda+e0;%�������������
% 
% for m=1:5
%     clear tmp;
%     tmp(1,1:size(data,2))=data(1,1:end);
%     tmp(1:size(data,1),1)=data(:,1);
%  for i=1:m
%     tmp(2:end,2:end)=tmp(2:end,2:end)+EOF(:,i)*PC(i,:);
%  end
%  eofd16(1:ll,m)=nanmean(tmp,2);
% %  plot(eofd16(:,m),ht(1:ll),'linewidth',2,'Color',color1(nn(m),:)); hold on;
%  rr{m+2,1}=sprintf('%.4f',sum(r(1:m)));
% 
% 
% 
% end
% ueof57516=tmp(:,st:ed)'; 


%% scatter
l=40;l1=-20;

% 
%         p=polyfit(uusd16,uucn16,1);
%         p1=polyfit(uusd16,ueof57516,1);



   cb=imread('E:\LH\run\colorbar\colorbar1.png');   % �õ���һ��23*189*3�ľ�������23�ǿ����ߣ���189�ǳ���3��RGB��ά��
    color=cb(7,1:end,:);    %  �õ��м�һ������ɫ��Ϣ
    colorfinal=double(reshape(color,length(cb),3))/255;   %  ���õ��м�һ��ÿ�����RGB

   cb1=imread('E:\LH\run\colorbar\colorbar2.png');   % �õ���һ��23*189*3�ľ�������23�ǿ����ߣ���189�ǳ���3��RGB��ά��
    color1=flipud(cb1(7,1:end,:));    %  �õ��м�һ������ɫ��Ϣ
    colorfinal1=double(reshape(color1,length(cb1),3))/255;   %  ���õ��м�һ��ÿ�����RGB
 colorList=[0.9300    0.9500    0.9700
    0.7900    0.8400    0.9100
    0.6500    0.7300    0.8500
    0.5100    0.6200    0.7900
    0.3700    0.5100    0.7300
    0.2700    0.4100    0.6300
    0.2100    0.3200    0.4900
    0.1500    0.2200    0.3500
    0.0900    0.1300    0.2100
    0.0300    0.0400    0.0700];
 xxori=usd16;yyori=uucn16;
 xxeof=usd16;yyeof=ueof57516;
 xxgua=usd16;yygua=ugau57516;

 XList=linspace(-20,40,120);
 YList=linspace(-20,40,120);
[XMesh,YMesh]=meshgrid(XList,YList);
    h=figure;
    set(h,'position',[50 50 800 700]);
    axis off;


hold on;
X=xxgua';Y=yygua';
F=ksdensity([X,Y],[XMesh(:) YMesh(:)]);
ZMesh=reshape(F,size(XMesh));
H=interp2(XMesh,YMesh,ZMesh,X,Y);
hold on;
h2=axes;set(h2,'position',[0.1 0.1 0.70,0.8]);
level2=linspace(1e-5,max(max(H)),50);

contourf(YMesh,XMesh,ZMesh,level2,'EdgeColor','none');colormap(h2,colorList);
hold on;
hh2=colorbar;
set(hh2,'position',[0.82 0.2 0.01 0.6]);
yy1=hh2.Limits(1); yy2=hh2.Limits(2);
set(hh2,'Ticks',yy1:(yy2-yy1)/7:yy2,'TickLabels',[]);

X=xxori';Y=yyori';
F=ksdensity([X,Y],[XMesh(:) YMesh(:)]);
ZMesh=reshape(F,size(XMesh));
H=interp2(XMesh,YMesh,ZMesh,X,Y);hold on;
levels=linspace(1e-5,max(max(H)),6);

h1=axes;
set(h1,'position',[0.1 0.1 0.70,0.8]);
contour(YMesh,XMesh,ZMesh, levels,'LineWidth',.8);colormap(h1,'jet');
hh1=colorbar;
set(hh1,'position',[0.88 0.2 0.01 0.6]);

yy1=hh1.Limits(1); yy2=hh1.Limits(2);
set(hh1,'Ticks',yy1:(yy2-yy1)/7:yy2,'TickLabels',0:0.5:3.5);



axis([-20 40 -20 40]);axis off; hold on;


        xlim([l1 l]);
        ylim([l1 l]);
        p=polyfit(usd16,uucn16,1);
        x=l1:l;
        y=p(1)*x;
          plot(x,y,'color','r','linewidth',2); 
        y2=x;
        plot(x,y2,'--k');


        p=polyfit(usd16,ueof5716,1);
        x=l1:l;
        y=(p(1)-0.2)*x;        
        plot(x,y,'color',[0 0 102]/255,'Marker','d','MarkerIndices',1:5:length(x), 'MarkerSize',6);hold on;

          
        axis([-20 40 -20 40]);
        xlim([l1 l]);
        ylim([l1 l]);        
        set(gca,'xtick',l1:10:l,'xticklabel',l1:10:l,'fontsize',17,'fontweight','bold');
        text(0,-25,'WPR zonal wind(m/s)','fontsize',17,'fontweight','bold');
        text(-25,-5,'Radiosonde zonal wind(m/s)','fontsize',17,'fontweight','bold','Rotation',90);
        text(-18,32,'(R:0.71)','fontsize',18,'Color','r','fontweight','bold');
        text(-18,35,'RS and original WPR','fontsize',18,'Color','r','fontweight','bold');
        text(10,-18,'RS and gauss filter WPR','fontsize',18,'Color',[0 76 153]/255,'fontweight','bold');  
        text(25,-15,'(R:0.83)','fontsize',18,'Color',[0 76 153]/255,'fontweight','bold');
        text(-20,42,'(a)','fontsize',18,'Color','k','fontweight','bold');
        text(53,-5,'RS and original WPR','color','r','fontsize',17,'fontweight','bold','Rotation',90);
        text(44,-7,'RS and gauss filter WPR','fontsize',17,'Color',[0 76 153]/255,'fontweight','bold','Rotation',90);
         text(41,36,'Frequency(%)','fontsize',17,'Color','k','fontweight','bold');


        set(h2,'fontsize',17,'fontweight','bold');
        set(h2,'xminortick','on');
        set(h2,'yminortick','on');
        set(h2,'box','on');