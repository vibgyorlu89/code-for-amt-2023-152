clear;clc;
filepath='D:\Data\sounding\';
for i=1:length(filelist)
    clear tmp2 tmp tmp3;
    
    yr=str2num(filelist(i).name(1:4));
    mt=str2num(filelist(i).name(5:6));
    dy=str2num(filelist(i).name(7:8));
    nn=datenum(yr,mt,dy)-datenum(2020,12,31);
    kk=(str2num(filelist(i).name(9:10)))/12+1;
    filename=[filedir,filelist(i).name];
    fid=fopen(filename,'r');
    firstline=fgetl(fid);
    nm1=0; ly=1;
    while~feof(fid)
        nextline=fgetl(fid);
        nm1=nm1+1;
    end
    fclose(fid);
    fid=fopen(filename,'r');
    firstline=fgetl(fid);    
    tmp=fscanf(fid,'%f',[20 nm1]);
    fclose(fid);
    [~,a]=find(tmp(1,:)==57516);
    tmp2=sortrows(tmp(:,a)',11);
    [x,~]=find(tmp2(:,19)==999999);   %删除风速缺测的行
    tmp2(x,:)=[];
    [x,~]=find(tmp2(:,18)==999999);   %删除风向缺测的行
    tmp2(x,:)=[];
    [x,~]=find(tmp2(:,20)==999999);   %删除位势高度缺测的行
    tmp2(x,:)=[];
    [hh,y,~]=unique(tmp2(:,20),'rows');
    tmp3=tmp2(y,18:20);

    u = -tmp3(:,2).*sin(tmp3(:,1)./180*pi);
    uusd57516(nn,kk,1:48) = interp1(tmp3(:,3),u,level,'linear');

%     sounddata57516(nn,kk,1,1:48) =interp1(tmp3(:,3),tmp3(:,2),level,'linear');%wind speed
%     sounddata57516(nn,kk,2,1:48) =interp1(tmp3(:,3),tmp3(:,1),level,'linear');%wind dire
    
end
uusd57516(uusd57516==0)=nan;
