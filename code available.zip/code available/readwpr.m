clear;clc;
filepath='D:\Data\cn2\cn2data\';
filelist=dir([filepath,'*57516*2021*txt']);
for i=1:length(filelist)
    filename=[filepath,filelist(i).name];
    fid=fopen(filename,'r');
    firstline=fgetl(fid);
    nm1=0; ly=1;
    while ~feof(fid)
        nextline=fgetl(fid);
        mm=str2num(nextline(11:12));
        dy=str2num(nextline(13:14));
        hr=str2num(nextline(15:16));
        mt=str2num(nextline(17:18));
        nn=datenum(2021,mm,dy)-datenum(2020,12,31);
        nm=12*hr+mt/5+1;
        if nm~=nm1
            ly=1;nm1=nm;
            cn2data57516(nn,nm,1:11,ly)=str2num(nextline);
        else
            ly=ly+1;
            cn2data57516(nn,nm,1:11,ly)=str2num(nextline);
        end
    end
    fclose(fid);
end

filelist=dir([filepath,'*57516*2021*txt']);
for i=1:length(filelist)
    filename=[filepath,filelist(i).name];
    fid=fopen(filename,'r');
    firstline=fgetl(fid);
    nm1=0; ly=1;
    while ~feof(fid)
        nextline=fgetl(fid);
        mm=str2num(nextline(11:12));
        dy=str2num(nextline(13:14));
        hr=str2num(nextline(15:16));
        mt=str2num(nextline(17:18));
        nn=datenum(2021,mm,dy)-datenum(2020,12,31);
        nm=12*hr+mt/5+1;
        if nm~=nm1
            ly=1;nm1=nm;
            cn2data57516(nn,nm,1:11,ly)=str2num(nextline);
        else
            ly=ly+1;
            cn2data57516(nn,nm,1:11,ly)=str2num(nextline);
        end
    end
    fclose(fid);
end

filelist=dir([filepath,'*57633*2021*txt']);
for i=1:length(filelist)
    filename=[filepath,filelist(i).name];
    fid=fopen(filename,'r');
    firstline=fgetl(fid);
    nm1=0; ly=1;
    while ~feof(fid)
        nextline=fgetl(fid);
        mm=str2num(nextline(11:12));
        dy=str2num(nextline(13:14));
        hr=str2num(nextline(15:16));
        mt=str2num(nextline(17:18));
        nn=datenum(2021,mm,dy)-datenum(2020,12,31);
        nm=12*hr+mt/5+1;
        if nm~=nm1
            ly=1;nm1=nm;
            cn2data57633(nn,nm,1:11,ly)=str2num(nextline);
        else
            ly=ly+1;
            cn2data57633(nn,nm,1:11,ly)=str2num(nextline);
        end
    end
    fclose(fid);
end

filelist=dir([filepath,'*57633*2021*txt']);
for i=1:length(filelist)
    filename=[filepath,filelist(i).name];
    fid=fopen(filename,'r');
    firstline=fgetl(fid);
    nm1=0; ly=1;
    while ~feof(fid)
        nextline=fgetl(fid);
        mm=str2num(nextline(11:12));
        dy=str2num(nextline(13:14));
        hr=str2num(nextline(15:16));
        mt=str2num(nextline(17:18));
        nn=datenum(2021,mm,dy)-datenum(2020,12,31);
        nm=12*hr+mt/5+1;
        if nm~=nm1
            ly=1;nm1=nm;
            cn2data57633(nn,nm,1:11,ly)=str2num(nextline);
        else
            ly=ly+1;
            cn2data57633(nn,nm,1:11,ly)=str2num(nextline);
        end
    end
    fclose(fid);
end