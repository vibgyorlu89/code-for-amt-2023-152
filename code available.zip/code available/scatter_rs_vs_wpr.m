clear;clc;
ll=48;
st=datenum(2021,1,1)-datenum(2020,12,31);
ed=datenum(2021,12,31)-datenum(2020,12,31);

load('E:\LH\mat\data57516.mat'); %StationNum,ObservTime,Latitude,Longitude,SampHeight,HorizWindD,HorizWindV,VertiWindV,HorizCredib,VertiCredib,Cn2Value
load('E:\LH\mat\uusd57516.mat');


load('E:\LH\mat\rain.mat'); 
RR=rain*1000;
for i=1:365
    PRE((i*2-1):i*2,1)=nanmean(RR((i*24-23):i*24,1),1);
end
PRE(PRE<1)=0;PRE(PRE>1)=1;

[a,~]=find(PRE<1);
[b,~]=find(PRE>=1);

ws57516=reshape(squeeze(data57516(st:ed,1:12:end,7,1:ll)),[(ed-st+1)*24 ll]); ws57516(ws57516==99999)=nan;
wd57516=reshape(squeeze(data57516(st:ed,1:12:end,6,1:ll)),[(ed-st+1)*24 ll]); wd57516(wd57516==99999)=nan;
uucn57516=-ws57516.*sin(wd57516./180*pi);


uusd16=reshape(uusd57516,[(ed-st+1)*2 ll]); 
data57516(data57516==99999)=nan;
uucn16=squeeze(-data57516(st:ed,1,7,1:ll).*sin(data57516(st:ed,1,6,1:ll)./180*pi));


load('E:\LH\mat\ht.mat');
load('E:\LH\mat\htsd.mat'); %day, line number, var(),layer
% 

  


%% scatter
l=40;l1=-20;
x=l1:l;
    h=figure;
    set(h,'position',[50 50 700 600]);


        xxrain=usd16(b,:); yyrain=uucn16(b,:);
        xxnorain=usd16(a,:); yynorain=uucn16(a,:);

        p=polyfit(xxrain,yyrain,1);
        p1=polyfit(xxnorain,yynorain,1);
        y=x;

    cb=imread('E:\LH\colorbar25.jpg');   % �õ���һ��23*189*3�ľ�������23�ǿ����ߣ���189�ǳ���3��RGB��ά��
    color=cb(7,1:end,:);    %  �õ��м�һ������ɫ��Ϣ
    colorfinal=double(reshape(color,length(cb),3))/255;   %  ���õ��м�һ��ÿ�����RGB



Xedge=linspace(-20,40,120);
Yedge=linspace(-20,40,120);
[N,~,~,binX,binY] = histcounts2(yyrain',xxrain',[-inf,Xedge(2:end-1),inf],[-inf,Yedge(2:end-1),inf]);

XedgeM=movsum(Xedge,2)/2;
YedgeM=movsum(Yedge,2)/2;
[Xedgemesh,Yedgemesh]=meshgrid(XedgeM(2:end),YedgeM(2:end));

h = fspecial('gaussian',round(120/1),6);%����ѡ�ø�˹�˲�
N2=imfilter(N,h);

ind = sub2ind(size(N2),binX,binY);
col = N2(ind);


scatter(yyrain',xxrain',20,col,'filled'); hold on;

yy=colorbar;
yy1=yy.Limits(1); yy2=yy.Limits(2);
set(yy,'Ticks',yy1:(yy2-yy1)/7:yy2,'TickLabels',0:0.5:3.5);
ylabel(yy,'Frequency(%)','fontsize',18,'fontweight','bold');
xlim([l1 l]);ylim([l1 l]);
y2=p(1)*x;
plot(x,y,'k','Linewidth',2);hold on;
plot(x,y2,'--k');

        ylabel('WPR zonal wind(m/s)','fontsize',18,'fontweight','bold');
        xlabel('Radiosonde zonal wind(m/s)','fontsize',18,'fontweight','bold');        
        text(-16,35,'(a)','fontsize',18,'Color','k','fontweight','bold');
        text(20,-18,'RS vs WPR rain','fontsize',18,'Color','k','fontweight','bold');
        text(25,-13,['(R:',sprintf('%.2f',p(1)),')'],'fontsize',18,'Color','k','fontweight','bold');  

        set(gca,'xminortick','on');
        set(gca,'yminortick','on');
        set(gca,'box','on');
        set(gca,'fontsize',18,'fontweight','bold');


scatter(yynorain',xxnorain',20,col,'filled'); hold on;
yy1=yy.Limits(1); yy2=yy.Limits(2);
set(yy,'Ticks',yy1:(yy2-yy1)/7:yy2,'TickLabels',0:0.5:3.5);
ylabel(yy,'Frequency(%)','fontsize',18,'fontweight','bold');
xlim([l1 l]);ylim([l1 l]);
y3=p1(1)*x;
plot(x,y,'k','Linewidth',2);hold on;
plot(x,y3,'--k');

        ylabel('WPR zonal wind(m/s)','fontsize',18,'fontweight','bold');
        xlabel('Radiosonde zonal wind(m/s)','fontsize',18,'fontweight','bold');        
        text(-16,35,'(b)','fontsize',18,'Color','k','fontweight','bold');
        text(20,-18,'RS vs WPR no rain','fontsize',18,'Color','k','fontweight','bold');
        text(25,-13,['(R:',sprintf('%.2f',p1(1)),')'],'fontsize',18,'Color','k','fontweight','bold');  

        set(gca,'xminortick','on');
        set(gca,'yminortick','on');
        set(gca,'box','on');
        set(gca,'fontsize',18,'fontweight','bold');