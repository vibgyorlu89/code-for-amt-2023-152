clear;clc;

path='E:\LH\run\data\cn2\AEOLUS\track\';
filelist=dir([path,'*DBL']);
kk=1;kk1=0;
kk2=1;kk3=0;
for i=1:length(filelist)
    
    clear a;
    filename=[path,filelist(i).name];
    CODA_FILE_ID=coda_open(filename);
    info=coda_fetch(CODA_FILE_ID);
    longitude=coda_fetch(CODA_FILE_ID,'mie_geolocation',-1,'windresult_geolocation/longitude_cog');
    time=coda_fetch(CODA_FILE_ID,'mie_geolocation',-1,'windresult_geolocation/datetime_cog');
    latitude=coda_fetch(CODA_FILE_ID,'mie_geolocation',-1,'windresult_geolocation/latitude_cog');
    [a,~]=find(longitude>104&longitude<110&latitude>28&latitude<32);      
    altitude=coda_fetch(CODA_FILE_ID,'mie_geolocation',-1,'windresult_geolocation/altitude_vcog');
    azi=coda_fetch(CODA_FILE_ID,'mie_geolocation',-1,'windresult_geolocation/los_azimuth');
    mie_hloswind=coda_fetch(CODA_FILE_ID,'mie_hloswind',-1,'windresult/mie_wind_velocity');
    mie_valid=coda_fetch(CODA_FILE_ID,'mie_hloswind',-1,'windresult/validity_flag');
    mie_estimated_error=coda_fetch(CODA_FILE_ID,'mie_wind_prod_conf_data',-1,'mie_wind_qc/hlos_error_estimate');
%     coda_close(CODA_FILE_ID);
    kk1=kk1+length(a);
    miedata(kk:kk1,1)=longitude(a);clear longitude;
    miedata(kk:kk1,2)=latitude(a);clear latitude;
    miedata(kk:kk1,3)=altitude(a);clear altitude;
    miedata(kk:kk1,4)=azi(a);clear azi;
    miedata(kk:kk1,5)=mie_estimated_error(a)/100;clear mie_estimated_error;
    miedata(kk:kk1,6)=mie_valid(a);clear mie_valid;
    miedata(kk:kk1,7)=mie_hloswind(a)/100;clear mie_hloswind;
    for j=kk:kk1
        tmp=datevec(datenum(2000,1,1)+floor(time(a(j-kk+1))/86400));
        miedata(j,8:10)=tmp(1:3);
        miedata(j,11)=floor((time(a(j-kk+1))-86400*floor(time(a(j-kk+1))/86400))/3600);
        miedata(j,12)=floor((time(a(j-kk+1))-86400*floor(time(a(j-kk+1))/86400)-miedata(j,11)*3600)/60);
    end
    kk=kk1+1;
    clear a;
    try
    longitude=coda_fetch(CODA_FILE_ID,'rayleigh_geolocation',-1,'windresult_geolocation/longitude_cog');
    time=coda_fetch(CODA_FILE_ID,'rayleigh_geolocation',-1,'windresult_geolocation/datetime_cog');
    latitude=coda_fetch(CODA_FILE_ID,'rayleigh_geolocation',-1,'windresult_geolocation/latitude_cog');
    [a,~]=find(longitude>104&longitude<110&latitude>28&latitude<32);      
    altitude=coda_fetch(CODA_FILE_ID,'rayleigh_geolocation',-1,'windresult_geolocation/altitude_vcog');
    azi=coda_fetch(CODA_FILE_ID,'rayleigh_geolocation',-1,'windresult_geolocation/los_azimuth');
    rayleigh_hloswind=coda_fetch(CODA_FILE_ID,'rayleigh_hloswind',-1,'windresult/rayleigh_wind_velocity');
    rayleigh_valid=coda_fetch(CODA_FILE_ID,'rayleigh_hloswind',-1,'windresult/validity_flag');
    rayleigh_estimated_error=coda_fetch(CODA_FILE_ID,'rayleigh_wind_prod_conf_data',-1,'rayleigh_wind_qc/hlos_error_estimate');
    coda_close(CODA_FILE_ID);
    kk3=kk3+length(a);
    rayleighdata(kk2:kk3,1)=longitude(a);clear longitude;
    rayleighdata(kk2:kk3,2)=latitude(a);clear latitude;
    rayleighdata(kk2:kk3,3)=altitude(a);clear altitude;
    rayleighdata(kk2:kk3,4)=azi(a);clear azi;
    rayleighdata(kk2:kk3,5)=rayleigh_estimated_error(a)/100;clear rayleigh_estimated_error;
    rayleighdata(kk2:kk3,6)=rayleigh_valid(a);clear rayleigh_valid;
    rayleighdata(kk2:kk3,7)=rayleigh_hloswind(a)/100;clear rayleigh_hloswind;
    for j=kk2:kk3
        tmp=datevec(datenum(2000,1,1)+floor(time(a(j-kk2+1))/86400));
        rayleighdata(j,8:10)=tmp(1:3);
        rayleighdata(j,11)=floor((time(a(j-kk2+1))-86400*floor(time(a(j-kk2+1))/86400))/3600);
        rayleighdata(j,12)=floor((time(a(j-kk2+1))-86400*floor(time(a(j-kk2+1))/86400)-rayleighdata(j,11)*3600)/60);
    end
    kk2=kk3+1;
    catch
      coda_close(CODA_FILE_ID);  
    end
end

[a,b]=find(miedata1(:,6)==1&miedata1(:,5)<=10);
% [a,b]=find();
er2=nanmean(miedata1(a,5),1);
er1=nanmean(miedata1(:,5),1);
nm=length(miedata1)-length(a);nmrt=nm/length(miedata1);


[a,b]=find(rayleighdata1(:,6)==1&rayleighdata1(:,5)<=7);
% [a,b]=find();
er3=nanmean(rayleighdata1(a,5),1);
er4=nanmean(rayleighdata1(:,5),1);
nm1=length(rayleighdata1)-length(a);nmrt1=nm1/length(rayleighdata1);