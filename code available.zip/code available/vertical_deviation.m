clear;clc;
ll=45;
load('E:\LH\mat\miecn2.mat');
load('E:\LH\mat\rayleighcn2.mat');
load('E:\LH\mat\mie2.mat');
load('E:\LH\mat\rayleigh2.mat');
load('E:\LH\mat\ht.mat');
load('E:\LH\mat\ht1.mat'); 
lonlat=[108.76,28.84];

ht=ht1*1000;

for i=1:45
    tmpori=sort(rayleigh2(i,1)-rayleighcn2(i,1));
    rayori(i,1)=nanmean(rayleigh2(i,1)-rayleighcn2(i,1));
    rayori(i,2)=std(rayleigh2(i,1)-rayleighcn2(i,1));
    [x,~]=find(tmpori>rayori(i,1)); 
    rayori(i,3)=rmse(tmpori(x),rayori(i,1),length(x));
    [x1,~]=find(tmpori<=rayori(i,1)); 
    rayori(i,4)=rmse(tmpori(x1),rayori(i,1),length(x1));


    tmpgau=sort(rayleigh2(i,1)-rayleighcn2(i,2));
    raygau(i,1)=nanmean(rayleigh2(i,1)-rayleighcn2(i,2));
    raygau(i,2)=std(rayleigh2(i,1)-rayleighcn2(i,2));
    [x,~]=find(tmpgau>raygau(i,1)); 
    raygau(i,3)=rmse(tmpgau(x),raygau(i,1),length(x));
    [x1,~]=find(tmpgau<=raygau(i,1)); 
    raygau(i,4)=rmse(tmpgau(x1),raygau(i,1),length(x1));

    
    
    tmpeof=sort(rayleigh2(i,1)-rayleighcn2(i,3));
    rayeof(i,1)=nanmean(rayleigh2(i,1)-rayleighcn2(i,3));
    rayeof(i,2)=std(rayleigh2(i,1)-rayleighcn2(i,3));
    [x,~]=find(tmpeof>rayeof(i,1)); 
    rayeof(i,3)=rmse(tmpeof(x),rayeof(i,1),length(x));
    [x1,~]=find(tmpeof<=rayeof(i,1)); 
    rayeof(i,4)=rmse(tmpeof(x1),rayeof(i,1),length(x1));

    tmpori=sort(mie2(i,1)-miecn2(:,1)); 
    mieori(i,1)=nanmean(mie2(i,1)-miecn2(:,1));
    mieori(i,2)=std(mie2(i,1)-miecn2(:,1));
    [x,~]=find(tmpori>mieori(i,1)); 
    mieori(i,3)=rmse(tmpori(x),mieori(i,1),length(x));
    [x1,~]=find(tmpori<=mieori(i,1)); 
    mieori(i,4)=rmse(tmpori(x1),mieori(i,1),length(x1));

    tmpgau=sort(mie2(i,1)-miecn2(:,2)); 
    miegau(i,1)=nanmean(mie2(i,1)-miecn2(:,2));
    miegau(i,2)=std(tmie2(i,1)-miecn2(:,2));
    [x,~]=find(tmpgau>miegau(i,1)); 
    miegau(i,3)=rmse(tmpgau(x),miegau(i,1),length(x));
    [x1,~]=find(tmpgau<=miegau(i,1)); 
    miegau(i,4)=rmse(tmpgau(x1),miegau(i,1),length(x1));

    tmpeof=sort(mie2(i,1)-miecn2(:,3));    
    mieeof(i,1)=nanmean(mie2(i,1)-miecn2(:,3));
    mieeof(i,2)=std(mie2(i,1)-miecn2(:,3));
    [x,~]=find(tmpeof>mieeof(i,1)); 
    mieeof(i,3)=rmse(tmpeof(x),mieeof(i,1),length(x));
    [x1,~]=find(tmpeof<=mieeof(i,1)); 
    mieeof(i,4)=rmse(tmpeof(x1),mieeof(i,1),length(x1));

end



ll=20;ll1=-20;hgt=9.5;
h=figure;
set(h,'position',[50 50 1000 1000]);
hh=subplot(2,2,1);
set(hh,'position',[0.08 0.54 0.4 0.4]);
plot(rayori(:,1)+rayori(:,4),ht,'Color',[102 51 0]/255,'linewidth',1.5);hold on;
plot(rayori(:,1)-rayori(:,3),ht,'Color',[102 51 0]/255,'linewidth',1.5);hold on;
fill([rayori(:,1)-rayori(:,3);flipud(rayori(:,1)+rayori(:,4))],[htori;flipud(ht)],[102 51 0]/255,'edgealpha', '0', 'facealpha', '.8')


plot(raygau(:,1)+raygau(:,4),ht,'Color',[153 255 153]/255,'linewidth',1.5);hold on;
plot(raygau(:,1)-raygau(:,3),ht,'Color',[153 255 153]/255,'linewidth',1.5);hold on;
fill([raygau(:,1)-raygau(:,3);flipud(raygau(:,1)+raygau(:,4))],[htgau;flipud(ht)],[153 255 153]/255,'edgealpha', '0', 'facealpha', '.5')

xx=zeros(length(htori),1);
plot(xx,htori,'--k','linewidth',1.5);hold on;
h(1)=plot(rayori(:,1),htori,'Color',[102 51 0]/255,'linewidth',1.5,'LineStyle','-', 'LineWidth',2,...
    'Marker','*','MarkerIndices',1:3:length(ht), 'MarkerSize',6);hold on;
h(2)=plot(raygau(:,1),htgau,'Color',[153 255 153]/255,'linewidth',1.5,'LineStyle','-', 'LineWidth',2,...
    'Marker','*','MarkerIndices',1:3:length(ht), 'MarkerSize',6);hold on;
xlim([ll1 ll]);
ylim([0 hgt]);
% xlabel('Wind speed difference(m/s)','fontsize',15,'fontweight','bold');  
set(gca,'fontsize',15,'fontweight','bold');
set(gca,'xtick',-30:10:30,'xticklabel',-30:10:30,'fontsize',15,'fontweight','bold');
ylabel('Height(m)','fontsize',15,'fontweight','bold');
text(-18,9.2,'(a)','fontsize',15,'fontweight','bold');
lgd=legend(h([1 2]),'Rayleigh-original WPR wind','Rayleigh-Gauss WPR wind','location','north','Box','off','fontsize',13); 
        set(gca,'xminortick','on');
        set(gca,'yminortick','on');
hh=subplot(2,2,2);
% set(hh,'position',[0.30 0.12 0.2 0.85]);
set(hh,'position',[0.53 0.54 0.4 0.4]);
plot(rayori(:,1)+rayori(:,4),ht,'Color',[102 51 0]/255,'linewidth',1.5);hold on;
plot(rayori(:,1)-rayori(:,3),ht,'Color',[102 51 0]/255,'linewidth',1.5);hold on;
fill([rayori(:,1)-rayori(:,3);flipud(rayori(:,1)+rayori(:,4))],[htori;flipud(ht)],[102 51 0]/255,'edgealpha', '0', 'facealpha', '.8')

plot(rayeof(:,1)+rayeof(:,4),ht,'Color',[153 255 153]/255,'linewidth',1.5);hold on;
plot(rayeof(:,1)-rayeof(:,3),ht,'Color',[153 255 153]/255,'linewidth',1.5);hold on;
fill([rayeof(:,1)-rayeof(:,3);flipud(rayeof(:,1)+rayeof(:,4))],[hteof;flipud(ht)],[153 255 153]/255,'edgealpha', '0', 'facealpha', '.5')

xx=zeros(length(htori),1);
plot(xx,htori,'--k','linewidth',1.5);hold on;
h(1)=plot(rayori(:,1),htori,'Color',[102 51 0]/255,'linewidth',1.5,'LineStyle','-', 'LineWidth',2,...
    'Marker','*','MarkerIndices',1:3:length(ht), 'MarkerSize',6);hold on;
h(2)=plot(rayeof(:,1),hteof,'Color',[153 255 153]/255,'linewidth',1.5,'LineStyle','-', 'LineWidth',2,...
    'Marker','*','MarkerIndices',1:3:length(ht), 'MarkerSize',6);hold on;
xlim([ll1 ll]);
ylim([0 hgt]);
% xlabel('Wind speed difference(m/s)','fontsize',15,'fontweight','bold');  
set(gca,'fontsize',15,'fontweight','bold');
set(gca,'xtick',-30:10:30,'xticklabel',-30:10:30,'fontsize',15,'fontweight','bold');
text(-18,9.2,'(b)','fontsize',15,'fontweight','bold');
lgd=legend(h([1 2]),'Rayleigh-original WPR wind','Rayleigh-EOF WPR wind','location','north','Box','off','fontsize',13); 
        set(gca,'xminortick','on');
        set(gca,'yminortick','on');
hh=subplot(2,2,3);
% set(hh,'position',[0.54 0.12 0.2 0.85]);
set(hh,'position',[0.08 0.08 0.4 0.40]);
plot(mieori(:,1)+mieori(:,4),ht,'Color',[102 51 0]/255,'linewidth',1.5);hold on;
plot(mieori(:,1)-mieori(:,3),ht,'Color',[102 51 0]/255,'linewidth',1.5);hold on;
fill([mieori(:,1)-mieori(:,3);flipud(mieori(:,1)+mieori(:,4))],[htmori;flipud(ht)],[102 51 0]/255,'edgealpha', '0', 'facealpha', '.8')

plot(miegau(:,1)+miegau(:,4),ht,'Color',[153 255 153]/255,'linewidth',1.5);hold on;
plot(miegau(:,1)-miegau(:,3),ht,'Color',[153 255 153]/255,'linewidth',1.5);hold on;
fill([miegau(:,1)-miegau(:,3);flipud(miegau(:,1)+miegau(:,4))],[htmgau;flipud(ht)],[153 255 153]/255,'edgealpha', '0', 'facealpha', '.5')

xx=zeros(length(htori),1);
plot(xx,htori,'--k','linewidth',1.5);hold on;
h(1)=plot(mieori(:,1),ht,'Color',[102 51 0]/255,'linewidth',1.5,'LineStyle','-', 'LineWidth',2,...
    'Marker','*','MarkerIndices',1:3:length(ht), 'MarkerSize',6);hold on;
h(2)=plot(miegau(:,1),ht,'Color',[153 255 153]/255,'linewidth',1.5,'LineStyle','-', 'LineWidth',2,...
    'Marker','*','MarkerIndices',1:3:length(ht), 'MarkerSize',6);hold on;
xlim([ll1 ll]);
ylim([0 hgt]);
set(gca,'fontsize',15,'fontweight','bold');
set(gca,'xtick',-30:10:30,'xticklabel',-30:10:30,'fontsize',15,'fontweight','bold');
xlabel('Wind speed difference(m/s)','fontsize',15,'fontweight','bold');
ylabel('Height(m)','fontsize',15,'fontweight','bold');
text(-18,9.2,'(c)','fontsize',15,'fontweight','bold');
lgd=legend(h([1 2]),'Mie-original WPR wind','Mie-Gauss WPR wind','location','north','Box','off','fontsize',13); 
        set(gca,'xminortick','on');
        set(gca,'yminortick','on');
hh=subplot(2,2,4);
% set(hh,'position',[0.78 0.12 0.2 0.85]);
set(hh,'position',[0.53 0.08 0.4 0.40]);
plot(mieori(:,1)+mieori(:,4),ht,'Color',[102 51 0]/255,'linewidth',1.5);hold on;
plot(mieori(:,1)-mieori(:,3),ht,'Color',[102 51 0]/255,'linewidth',1.5);hold on;
fill([mieori(:,1)-mieori(:,3);flipud(mieori(:,1)+mieori(:,4))],[ht;flipud(ht)],[102 51 0]/255,'edgealpha', '0', 'facealpha', '.8')

plot(mieeof(:,1)+mieeof(:,4),ht,'Color',[153 255 153]/255,'linewidth',1.5);hold on;
plot(mieeof(:,1)-mieeof(:,3),ht,'Color',[153 255 153]/255,'linewidth',1.5);hold on;
fill([mieeof(:,1)-mieeof(:,3);flipud(mieeof(:,1)+mieeof(:,4))],[ht;flipud(ht)],[153 255 153]/255,'edgealpha', '0', 'facealpha', '.5')

xx=zeros(length(htori),1);
plot(xx,htori,'--k','linewidth',1.5);hold on;
h(1)=plot(mieori(:,1),ht,'Color',[102 51 0]/255,'linewidth',1.5,'LineStyle','-', 'LineWidth',2,...
    'Marker','*','MarkerIndices',1:3:length(ht), 'MarkerSize',6);hold on;
h(2)=plot(mieeof(:,1),ht,'Color',[153 255 153]/255,'linewidth',1.5,'LineStyle','-', 'LineWidth',2,...
    'Marker','*','MarkerIndices',1:3:length(ht), 'MarkerSize',6);hold on;
xlim([ll1 ll]);
ylim([0 hgt]);
set(gca,'fontsize',15,'fontweight','bold');
set(gca,'xtick',-30:10:30,'xticklabel',-30:10:30,'fontsize',15,'fontweight','bold');
xlabel('Wind speed difference(m/s)','fontsize',15,'fontweight','bold');  
text(-18,9.2,'(d)','fontsize',15,'fontweight','bold');
lgd=legend(h([1 2]),'Mie-original WPR wind','Mie-EOF WPR wind','location','north','Box','off','fontsize',13);    %,'Orientation','horizontal'

        set(gca,'xminortick','on');
        set(gca,'yminortick','on');
function [rms] = rmse(obsdata,meandata,ll)        %%均方根误差
    ss=0;
    for i=1:ll
         ss=ss+(obsdata(i)-meandata)^2;
    end
    rms=sqrt(ss/ll);
end