clear;clc;
ll=48;
st=datenum(2021,1,1)-datenum(2020,12,31);
ed=datenum(2021,12,31)-datenum(2020,12,31);

load('E:\LH\mat\rain.mat'); 
load('E:\LH\mat\data57516.mat'); %StationNum,ObservTime,Latitude,Longitude,SampHeight,HorizWindD,HorizWindV,VertiWindV,HorizCredib,VertiCredib,Cn2Value
load('E:\LH\mat\uusd57516.mat');

RR=rain*1000;
for i=1:365
    PRE((i*2-1):i*2,1)=nanmean(RR((i*24-23):i*24,1),1);
end
PRE(PRE<1)=0;PRE(PRE>1)=1;

[a,~]=find(PRE<1);
[b,~]=find(PRE>=1);

ws57516=reshape(squeeze(data57516(st:ed,1:12:end,7,1:ll)),[(ed-st+1)*24 ll]); ws57516(ws57516==99999)=nan;
wd57516=reshape(squeeze(data57516(st:ed,1:12:end,6,1:ll)),[(ed-st+1)*24 ll]); wd57516(wd57516==99999)=nan;

uucn57516=-ws57516.*sin(ws57516./180*pi);


uuera57516=reshape(eradata57516(st:ed,:,1,:),[24*(ed-st+1),20]);

uusd16=reshape(uusd57516,[(ed-st+1)*2 ll]);
data57516(data57516==99999)=nan;
uucn16=squeeze(-data57516(st:ed,1,7,1:ll).*sin(data57516(st:ed,1,6,1:ll)./180*pi));

load('E:\LH\mat\ht.mat');
load('E:\LH\mat\htsd.mat');% 

for j=1:length(usd16)
    usd16(j,1:length(htsd))=interp1(htsd,uusd16(j,:),ht);
end



%% statistic plot


l=40;l1=-40;
    h=figure;
    set(h,'position',[50 50 1400 600]);

        for i=7:length(ht)
            clear tmp1 tmp2 tmp3 tmp4;
            tmp1=usd16(:,i);tmp2=uucn16(:,i);
            tmp0=tmp1;tmp00=tmp2;
            tmp1(isnan(tmp2))=[];tmp2(isnan(tmp2))=[];
            tmp2(isnan(tmp1))=[];tmp1(isnan(tmp1))=[];
            
            
            tmp3=usd16(b,i);tmp4=uucn16(b,i);
            tmp3(isnan(tmp4))=[];tmp4(isnan(tmp4))=[];
            tmp4(isnan(tmp3))=[];tmp3(isnan(tmp3))=[];

            tmp5=usd16(a,i);tmp6=uucn16(a,i);
            tmp5(isnan(tmp6))=[];tmp6(isnan(tmp6))=[];
            tmp6(isnan(tmp5))=[];tmp5(isnan(tmp5))=[];

            rmse(i,1)=rms(tmp1-tmp2);
            mb(i,1)=sum(tmp1-tmp2)/length(tmp1);
            rmse(i,2)=rms(tmp3-tmp4);
            mb(i,2)=sum(tmp3-tmp4)/length(tmp3);
            rmse(i,3)=rms(tmp5-tmp6);
            mb(i,3)=sum(tmp5-tmp6)/length(tmp5);

            cor=corrcoef(tmp1,tmp2);
            r(i,1)=cor(1,2);

            tmp3(isnan(tmp4))=[];tmp4(isnan(tmp4))=[];
            tmp4(isnan(tmp3))=[];tmp3(isnan(tmp3))=[];


        end

 
    subplot(1,2,1);
        rmse(rmse==0)=nan; mb(mb==0)=nan; r(r==0)=nan;    
        plot(rmse(:,2),ht,'b','linewidth',2);hold on;
        plot(rmse(:,3),ht,'g','linewidth',2,'Marker','*','MarkerIndices',1:5:length(ht), 'MarkerSize',6);hold on;
        plot(rmse(:,1),ht,'r','linewidth',2,'Marker','^','MarkerIndices',1:5:length(ht), 'MarkerSize',6);
%         set(gca,'xtick',l1:10:l,'xticklabel',l1:10:l,'fontsize',15,'fontweight','bold');
        ylabel('Height(m)','fontsize',18,'fontweight','bold');
        xlabel('RMSE(m/s)','fontsize',18,'fontweight','bold');  
        set(gca,'fontsize',18,'fontweight','bold'); 
        set(gca,'xminortick','on');
        set(gca,'yminortick','on');
        text(2.3,6.5,'(c)','fontsize',15,'fontweight','bold'); 
    subplot(1,2,2);        
        plot(mb(:,3),ht,'b','linewidth',2);hold on;
        plot(mb(:,2),ht,'g','linewidth',2,'Marker','*','MarkerIndices',1:5:length(ht), 'MarkerSize',6);hold on;
        plot(mb(:,1),ht,'r','linewidth',2,'Marker','^','MarkerIndices',1:5:length(ht), 'MarkerSize',6);
        set(gca,'xtick',-5:1:1,'xticklabel',-5:1:1,'fontsize',18,'fontweight','bold');
        ylabel('Height(m)','fontsize',18,'fontweight','bold');
        xlabel('Mean Bias(m/s)','fontsize',18,'fontweight','bold'); 

        lgd=legend('RS-WPR rain','RS-WPR no rain','RS-WPR all','location','south','Orientation','horizontal');    
        set(lgd,'Box','off')
        set(gca,'fontsize',18,'fontweight','bold'); 
        text(-4.5,6.5,'(d)','fontsize',15,'fontweight','bold'); 
        set(gca,'fontsize',18,'fontweight','bold'); 
        ylim([0 7]);
        xlim([-5 1]);
        set(gca,'xminortick','on');
        set(gca,'yminortick','on');
   